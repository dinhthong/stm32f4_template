# STM32F4 rosserial full project
- Rosserial on PA2, PA3
# Preferences
- https://github.com/xav-jann1/rosserial_stm32f4
- https://github.com/yoneken/rosserial_stm32
- https://www.youtube.com/watch?v=cq0HmKrIOt8
- https://github.com/SyrianSpock/stm32f4discovery_rosserial (tested ok)
# Other projects
- https://github.com/Lembed/ROS-FreeRTOS-STM32
- https://www.youtube.com/watch?v=7Nwue0bPGnU&ab_channel=%EA%B3%B5%EB%8D%95Project